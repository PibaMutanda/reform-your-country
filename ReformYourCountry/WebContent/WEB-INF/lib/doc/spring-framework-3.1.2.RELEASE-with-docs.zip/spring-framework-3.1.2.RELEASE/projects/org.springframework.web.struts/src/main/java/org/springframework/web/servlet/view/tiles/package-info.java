/**
 * Support classes for the integration of
 * <a href="http://www.lifl.fr/~dumoulin/tiles">Tiles</a>
 * (included in Struts) as Spring web view technology.
 * Contains a View implementation for Tiles definitions.
 */

package org.springframework.web.servlet.view.tiles;
