INSERT INTO drivers_license(id, license_number) values(1, 1234);

INSERT INTO person(id, name, drivers_license_id) values(1, 'Sam', 1);
