
/**
 *
 * <p>JUnit 4.5 based <code>statements</code> used in the <em>Spring TestContext Framework</em>.</p>
 *
 */
package org.springframework.test.context.junit4.statements;

