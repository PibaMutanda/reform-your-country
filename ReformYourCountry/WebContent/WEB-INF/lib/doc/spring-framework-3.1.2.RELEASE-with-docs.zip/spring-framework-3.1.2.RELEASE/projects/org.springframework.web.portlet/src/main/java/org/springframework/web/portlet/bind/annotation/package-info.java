
/**
 *
 * Annotations for binding portlet requests to handler methods.
 *
 */
package org.springframework.web.portlet.bind.annotation;

