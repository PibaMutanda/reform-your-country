
/**
 *
 * Support classes for the integration of
 * <a href="http://tiles.apache.org">Tiles2</a>
 * (the standalone version of Tiles) as Spring web view technology.
 * Contains a View implementation for Tiles definitions.
 *
 */
package org.springframework.web.servlet.view.tiles2;

